import React from "react";

const icon = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -256 1792 1792" width="100%" height="100%">
      <g transform="matrix(1,0,0,-1,53.152542,1262.6441)">
        <path d="m 1611,565 q 0,-51 -37,-90 l -75,-75 q -38,-38 -91,-38 -54,0 -90,38 L 1024,693 V -11 q 0,-52 -37.5,-84.5 Q 949,-128 896,-128 H 768 q -53,0 -90.5,32.5 Q 640,-63 640,-11 V 693 L 346,400 q -36,-38 -90,-38 -54,0 -90,38 l -75,75 q -38,38 -38,90 0,53 38,91 l 651,651 q 35,37 90,37 54,0 91,-37 l 651,-651 q 37,-39 37,-91 z" fill="currentColor" />
      </g>
    </svg>
  );
};
export default icon;
