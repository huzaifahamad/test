---
id: d036a5c3-e7a1-4d0b-9084-2ce5205b1174
templateKey: author-page
title: Test Author
slug: test-author
image: /img/sample-person.png
description: This is Author of XYZ
seoTitle: Author of XYZ
seoDescription: I am Author of XYZ
---
