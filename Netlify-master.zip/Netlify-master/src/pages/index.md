---
templateKey: index-page
seoTitle: Index Title
seoDescription: Index Description
categories:
  - title: Buying Guides
    links:
      - title: Best Buying Guides
        link: /sample-post-buying/
---
